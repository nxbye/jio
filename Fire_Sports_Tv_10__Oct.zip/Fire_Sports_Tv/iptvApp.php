<?php

include("_configs.php");

$request = "";
if(isset($_REQUEST['request'])) {
    $request = trim($_REQUEST['request']);
}

$allTV = tvcdata();
if(!is_array($allTV)) {
    response("error", "Service Unavailable", "");
}

if($request == "get_channels")
{
    $livetv = array();
    if(empty($allTV)) { response("error", "No TV Channels Found", ""); }
    foreach($allTV as $etv)
    {
        $livetv[] = array("id" => $etv['sid'],
                          "title" => $etv['title'],
                          "logo" => $etv['logo']);
    }
    response("success", "Total ".count($livetv)." Channels Found", array("count" => count($livetv), "list" => $livetv));
}
elseif($request == "get_channel_details")
{
    $id = ""; $detail = array();
    if(isset($_REQUEST['id'])) { $id= trim($_REQUEST['id']); }
    if(empty($id)) { response("error", "Channel ID Required", ""); }
    foreach($allTV as $etv)
    {
        if(md5($id) == md5($etv['sid']))
        {
            $detail = $etv;
        }
    }
    if(empty($detail)) { response("error", "Channel ID Invalid", ""); }
    if($_SERVER['SERVER_PORT'] !== "80" && $_SERVER['SERVER_PORT'] !== "443")
    {
        $playUrlBase = $streamenvproto."://".$plhoth.":".$_SERVER['SERVER_PORT'].str_replace(" ", "%20", str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF']));
    }
    else
    {
        $playUrlBase = $streamenvproto."://".$plhoth.str_replace(" ", "%20", str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF']));
    }
    $playurl = $playUrlBase."stream.".$HLS_EXT."?id=".$detail['sid']."&e=.m3u8";
    response("success", "OK", array("id" => $detail['sid'],
                                    "title" => $detail['title'],
                                    "logo" => $detail['logo'],
                                    "playurl" => $playurl));
}
elseif($request == "get_iptvplaylist")
{
    if(empty($allTV)) { http_response_code(503); exit(); }
    $playlistData = '#EXTM3U'."\n";
    foreach($allTV as $ltv)
    {
        $playlistData .= '#EXTINF:-1 tvg-id="'.$ltv['id'].'" tvg-name="'.$ltv['title'].'" tvg-country="IN" tvg-logo="'.$ltv['logo'].'" tvg-chno="'.$ltv['id'].'" group-title="FireSports (iNovaTech)",'.$ltv['title']."\n";
        if($_SERVER['SERVER_PORT'] !== "80" && $_SERVER['SERVER_PORT'] !== "443")
        {
            $playUrlBase = $streamenvproto."://".$plhoth.":".$_SERVER['SERVER_PORT'].str_replace(" ", "%20", str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF']));
        }
        else
        {
            $playUrlBase = $streamenvproto."://".$plhoth.str_replace(" ", "%20", str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF']));
        }
        $playurl = $playUrlBase."stream.".$HLS_EXT."?id=".$ltv['sid']."&e=.m3u8";
        $playlistData .= $playurl."\n";
    }
    
    $pfile = "FireSports_" . time() . "_iNovaTechHub.m3u";
    header('Content-Disposition: attachment; filename="'.$pfile.'"');
    header("Content-Type: application/vnd.apple.mpegurl");
    exit($playlistData);
}
else
{
    response("error", "Bad Request", "");
}

?>