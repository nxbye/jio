<?php

include("_configs.php");

$id = ""; $segment = "";
if(isset($_REQUEST['id'])){ $id = trim($_REQUEST['id']); }
if(isset($_REQUEST['segment'])){ $segment = trim($_REQUEST['segment']); }

header("Access-Control-Allow-Origin: *");

$streamheads = array("Origin: ".getStreamRefererOrigin(),
                     "Referer: ".getStreamRefererOrigin()."/",
                     "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36");
if(!empty($id))
{
    $streamURL = fetch_cached_Streamlink($id);
    if(empty($streamURL)) {
        http_response_code(404);
        exit();
    }
    $options = array(
        'http' => array(
        'header' => implode("\r\n", $streamheads)
    ));
    $context = stream_context_create($options);
    $content = file_get_contents($streamURL, false, $context);
    if(stripos($content, "#EXTM3U") !== false)
    {
        $iBaseURL = getStreamBaseURL($streamURL);
        $line = explode("\n", $content);
        $kine  = "";
        foreach($line as $vine)
        {
            if(stripos($vine, ".ts") !== false)
            {
                if($FIRE_APP_CONFIGS['USE_WORLDWIDE_PROXY'] == "YES")
                {
                    $kine .= "stream.".$TS_EXT."?segment=".streamEnc("encrypt", $iBaseURL.$vine)."\n";
                }
                else
                {
                    $kine .= $iBaseURL.$vine."\n";
                }
            }
            else
            {
                $kine .= $vine."\n";
            }
        }
        header("Content-Type: application/vnd.apple.mpegurl");
        exit(trim($kine));
    }
    else
    {
        http_response_code(503);
        exit();
    }

}
elseif(!empty($segment))
{
    $streamURL = streamEnc("decrypt", $segment);
    if(!filter_var($streamURL, FILTER_VALIDATE_URL)) {
        http_response_code(400);
        exit();
    }
    $options = array(
        'http' => array(
        'header' => implode("\r\n", $streamheads)
    ));
    $context = stream_context_create($options);
    $content = file_get_contents($streamURL, false, $context);
    if(!empty($content))
    {
        header("Content-Type: video/m2ts");
        exit($content);
    }
    else
    {
        http_response_code(410);
        exit();
    }
}
else
{
    http_response_code(400);
    exit();
}

?>