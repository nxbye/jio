<?php

include("_configs.php");

$watch = "";
if(isset($_REQUEST['watch'])) {
  $watch = trim($_REQUEST['watch']);
}

if(!empty($watch))
{
?>

<html>
<head>
<title>Player - FireSports TV</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<link rel="stylesheet" href="player.css?v=<?php print(time()); ?>"/>
<link rel="shortcut icon" href="favicon.ico"/>
<script src="https://content.jwplatform.com/libraries/IDzF9Zmk.js"></script>
<style>
body {
  overflow: hidden;
}
</style>
</head>

<body>
<div id="loading" class="loading">
      <div style="" class="loading-text">
        <span style="" class="loading-text-words">F</span>
        <span style="" class="loading-text-words">I</span>
        <span style="" class="loading-text-words">R</span>
        <span style="" class="loading-text-words">E</span>
        <span style="" class="loading-text-words">-</span>
        <span style="" class="loading-text-words">S</span>
        <span style="" class="loading-text-words">P</span>
        <span style="" class="loading-text-words">O</span>
        <span style="" class="loading-text-words">R</span>
        <span style="" class="loading-text-words">T</span>
        <span style="" class="loading-text-words">S</span>
      </div>
    </div>
    <div id="vplayer" style="height: auto; text-align: center;"></div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
$(document).ready(function(){
    player_details();
});
function player_details()
{
    let encodedID = getParameterByName("watch");
    if(encodedID == "" || encodedID == null || encodedID == undefined)
    {
        window.location = "?home";
    }
    else
    {
        $.ajax({
            "url": "iptvApp.php",
            "type": "POST",
            "data": "request=get_channel_details&id=" + encodedID,
            "success": function(data)
            {
                try { data = JSON.parse(data); }catch(err){}
                if(data.status == "success")
                {
                    attach_player(data.data.playurl, data.data.logo);
                    document.title = data.data.title + " [Live] - FireSports TV";
                }
                $("body").fadeIn();
            },
            "error": function(data)
            {
                alert("API Error");
            }
        });
    }
}
function attach_player(playurl, logo)
{
    window.setTimeout(function(){ $("#loading").fadeOut(); }, 1500);
    jwplayer("vplayer").setup(
    {
        sources:
        [
            { file:playurl}
        ],
        autostart: false,
        width:"100%",
        image: logo,
        height:"auto",
        stretching:"uniform",
        duration:"",
        preload:"metadata",
        androidhls:"true",
        hlshtml:"false",
        primary:"html5",
        startparam:"start",
        playbackRateControls:[0.25,0.5,0.75,1,1.25,1.5,2],
        logo:
        {
            file:"",
            link:"",
            position:"top-right",
            margin:"5",
            hide:true
        }
    });
    jwplayer().play();
}

function attach_player_dash(playurl, drmurl, poster)
{
    window.setTimeout(function(){ $("#loading").fadeOut(); }, 1500);
  jwplayer("vplayer").setup(
   {
  "playlist": [
    {
      "sources": [
        {
          "default": false,
          "type": "mpd",
          "file": playurl,
          "drm": {
            "widevine": {
              "url": drmurl
            }
          },
          "label": "0"
        }
      ]
    }
  ],
  "logo":
    {
        "file": poster,
        "hide": true,
        "position": 'top-right'
    },
  "primary": "html5",
  "hlshtml": true,
  "image": poster,
  "autostart": false,
  "playbackRateControls":[0.25,0.5,0.75,1,1.25,1.5,2],
    });
    jwplayer().play();
}


function getParameterByName(name)
{
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
    results = regex.exec(decodeURIComponent(location.search));
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
</script>
</body>

</html>

<?php
}
else
{
?>

<html>
<head>
<title>FireSports TV </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no"/>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link href="https://fonts.googleapis.com/css2?family=Ubuntu&display=swap" rel="stylesheet"/>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
<link rel="shortcut icon" href="favicon.ico"/>
<link href="https://fonts.googleapis.com/css2?family=Montserrat&family=Playfair+Display&family=Roboto&family=Roboto+Slab&display=swap" rel="stylesheet">
<style> 
@import url('https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap');
html { background-color: #000000; }
body
{
  text-align:center;
  align-items:center;
  background-color: #000000;
  overflow-x: hidden;
  display: none;
  font-family: 'Roboto Condensed', sans-serif;
  padding-left: 3px;
  padding-right: 3px;
}
.box1
{
    display: inline-block;
    border:2px solid black;
    text-align:center;
    align-items:center;
    margin:5px;
    background-color:#050708;
    border-radius:2rem .3rem ;
    text-align:center;
    margin-left:-.8rem;
    margin-right:.85rem;
    height:auto;
	padding-top:1rem;
}
.container
{
    width:100%;
    margin-left:.6rem;
}
.box1:hover
{
  background-color: rgba(165, 42, 42, 0.521);
	border-color:white;
	border:2px solid white;
}
.box1:hover .card-text
{
    color:white;
}
.box1 a
{
    text-decoration: none;
    color: #FFFFFF;
    line-height:10px;
}
input:focus
{
    transition: cubic-bezier(0.075, 0.82, 0.165, 1);
    border-color: #1AD33C;
}
#brand
{
    text-decoration:none;
    color: white;
}
select
{
    text-align: center;
    width:40%;
    height:38px;
    border: 1.5px solid yellow;
    border-radius:1rem;margin-left:-1.2rem;
}
option
{
    line-height:35px ;
    border: 1px solid black;
    border-radius:1.5rem;
    font-size:18px;
}
input
{
    width:40%;
    height:38px;
    border: 1.5px solid yellow;
    text-align: center;
    border-radius:1rem;
    font-size:18px;
    margin-left:-.4rem;
}
input:hover
{
    border:4px solid orangered;
}
.con 
{
    display:flexbox;
    width:100%;
    margin:15px;
    text-align: center;
}
.dropbtn
{
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  width:100%;
  border-radius:1rem;
  background-color:orangered;
  font-size: 16px;
  border: none;
  cursor: pointer;
}
.dropdown
{
  position: relative;
  display: inline-block;
  width: :80% ;
}
.dropdown-content
{
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 100%;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}
.dropdown-content a
{
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}
.dropdown-content a:hover {background-color: #f1f1f1}
.dropdown:hover .dropdown-content
{
  display: block;
}
.dropdown:hover .dropbtn
{
  background-color: #3e8e41;
}
@media only screen and (max-width: 768px)
{
 select, input, .drpbtn , .dropdown{
    width:85%;
}
}
.responsive-img {
    max-width: 100%;
    height: auto;
  }
</style>
<script src="https://cdn.jsdelivr.net/npm/lazysizes@5.3.2/lazysizes.min.js"></script>
</head>
<body>

<div id="jtvh1">
<a id="brand" href="?home">
<img height="95" width="240" src="FireSports_Logo.png" style="pointer-events: none;" alt="AppLogo iNovaTechHub" />
</a>
<br/><br/>
<a href="iptvApp.php?request=get_iptvplaylist" style="text-decoration: none; color:#FFFFFF; font-weight: bold;">Download IPTV Playlist</a>
</div>

<br/><br/>

 <form>
     <input id="search" type="search" placeholder="Search"/>
 </form>
</div>

<div id="content">
<div class="container" id="tv_catalog"></div>
</div>

<p>
<br/>
<a href="" style="color: red; font-weight: bold; text-decoration: none;"></a>
</p>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
$(document).ready(function(){
  load_tv_list();
  $("input").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $(".box1").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
function load_tv_list()
{
  $.ajax({
    "url": "iptvApp.php",
    "type": "POST",
    "data": "request=get_channels",
    "success":function(data)
    {
      try { data = JSON.parse(data); }catch(err){}
      if(data.status == "success")
      {
        let utml = '';
        $.each(data.data.list, function(k,v){
          utml = utml + '<div class="box1">';
          utml = utml + '<a class="card" href="?watch=' + v.id +'" title="' + v.title +'">';
          utml = utml + '<img width="160" height="130" class="lazyload" src="' + v.logo +'">';
          utml = utml + '<div class="card-body">';
          utml = utml + '<p class="card-text">' + v.title + '</p>';
          utml = utml + '</div>';
          utml = utml + '</a>';
          utml = utml + '</div>';
        });
        $("#tv_catalog").html(utml);
        $("body").fadeIn();
      }
    },
    "error":function(data)
    {
        alert("Network Failed or Internal Server Error Occured");
    }
  });
}
</script>
</body>
</html>

<?php
}
?>