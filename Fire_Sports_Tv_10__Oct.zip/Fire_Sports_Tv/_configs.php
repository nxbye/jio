<?php

error_reporting(0);

$FIRE_APP_CONFIGS['USE_CUSTOM_STRM_EXT'] = "NO"; //Possible Values "YES" or "NO" -- Changing This To "YES" will serve the stream over .m3u8 and .ts extension
$FIRE_APP_CONFIGS['USE_WORLDWIDE_PROXY'] = "YES"; //Possible Values "YES" or "NO" -- Changing This To "NO" will not proxy ts files

$FIRE_APP_CONFIGS['APP_STORAGE_FOLDER'] = "AppData";
$FIRE_APP_CONFIGS['JS_EMBED'] = "https://stream.crichd.vip/update/skys2.php";

//===================================================================================//

$streamenvproto = "http";
if(isset($_SERVER['HTTPS'])){ if($_SERVER['HTTPS'] == "on"){ $streamenvproto = "https"; } }
if(isset($_SERVER['HTTP_X_FORWARDED_PROTO'])){ if($_SERVER['HTTP_X_FORWARDED_PROTO'] == "https"){ $streamenvproto = "https"; }}

if(stripos($_SERVER['HTTP_HOST'], ':') !== false) {
    $warl = explode(':', $_SERVER['HTTP_HOST']);
    if(isset($warl[0]) && !empty($warl[0])){ $_SERVER['HTTP_HOST'] = trim($warl[0]); }
}
if(stripos($_SERVER['HTTP_HOST'], 'localhost') !== false){ $_SERVER['HTTP_HOST'] = str_replace('localhost', '127.0.0.1', $_SERVER['HTTP_HOST']); }
$local_ip = getHostByName(php_uname('n'));
if($_SERVER['SERVER_ADDR'] !== "127.0.0.1"){ $plhoth = $_SERVER['HTTP_HOST'];  }else{ $plhoth = $local_ip;  }
$plhoth = str_replace(" ", "%20", $plhoth);

if(isset($FIRE_APP_CONFIGS['APP_STORAGE_FOLDER']) || empty($FIRE_APP_CONFIGS['APP_STORAGE_FOLDER'])){ $FIRE_APP_CONFIGS['APP_STORAGE_FOLDER'] = "AppData"; }
if(!is_dir($FIRE_APP_CONFIGS['APP_STORAGE_FOLDER'])){ mkdir($FIRE_APP_CONFIGS['APP_STORAGE_FOLDER']); }
if(!file_exists($FIRE_APP_CONFIGS['APP_STORAGE_FOLDER']."/.htaccess")){ @file_put_contents($FIRE_APP_CONFIGS['APP_STORAGE_FOLDER']."/.htaccess", "deny from all"); }

if(!isset($FIRE_APP_CONFIGS['USE_CUSTOM_STRM_EXT']) || empty($FIRE_APP_CONFIGS['USE_CUSTOM_STRM_EXT'])){ $FIRE_APP_CONFIGS['USE_CUSTOM_STRM_EXT'] = "NO"; }
if($FIRE_APP_CONFIGS['USE_CUSTOM_STRM_EXT'] !== "YES" && $FIRE_APP_CONFIGS['USE_CUSTOM_STRM_EXT'] !== "NO"){ $FIRE_APP_CONFIGS['USE_CUSTOM_STRM_EXT'] = "NO"; }
if($FIRE_APP_CONFIGS['USE_CUSTOM_STRM_EXT'] == "YES"){ $HLS_EXT = "m3u8"; $TS_EXT = "ts"; }else{ $HLS_EXT = $TS_EXT = "php"; }

if(isset($FIRE_APP_CONFIGS['USE_WORLDWIDE_PROXY']) || empty($FIRE_APP_CONFIGS['USE_WORLDWIDE_PROXY'])){ $FIRE_APP_CONFIGS['USE_WORLDWIDE_PROXY'] = "YES"; }
if($FIRE_APP_CONFIGS['USE_WORLDWIDE_PROXY'] !== "YES" && $FIRE_APP_CONFIGS['USE_WORLDWIDE_PROXY'] !== "NO"){ $FIRE_APP_CONFIGS['USE_WORLDWIDE_PROXY'] = "YES"; }

if(file_exists($FIRE_APP_CONFIGS['APP_STORAGE_FOLDER']."/crKey")){ if(!empty(file_get_contents($FIRE_APP_CONFIGS['APP_STORAGE_FOLDER']."/crKey"))){ $CRYPTO_KEY = @file_get_contents($FIRE_APP_CONFIGS['APP_STORAGE_FOLDER']."/crKey"); } }
if(!isset($CRYPTO_KEY) || empty($CRYPTO_KEY)){ @file_put_contents($FIRE_APP_CONFIGS['APP_STORAGE_FOLDER']."/crKey", md5(rand(00000, 99999))); }
//====================================================================================//

function getStreamRefererOrigin()
{
    $output = "";
    $elink = fetch_cached_EmbedLink();
    if(!empty($elink))
    {
        $plink = parse_url($elink);
        if(isset($plink['host']) && isset($plink['scheme']))
        {
            $output = $plink['scheme']."://".$plink['host'];
        }
    }
    return $output;
}

function getStreamBaseURL($url)
{
    if(stripos($url, "?") !== false)
    {
        $mrl = explode("?", $url);
        if(isset($mrl[0]) && !empty($mrl[0]))
        {
            $url = trim($mrl[0]);
        }
    }
    return str_replace(basename($url), "", $url);
}

function streamEnc($action, $data)
{
    global $CRYPTO_KEY;
    $output = "";
    $iv = "somanyproblemsss";
    $ky = substr(sha1($CRYPTO_KEY), 0, 16);
    if($action == "encrypt")
    {
        $encrypted = openssl_encrypt($data, "AES-128-CBC", $ky, OPENSSL_RAW_DATA, $iv);
        if(!empty($encrypted)) { $output = bin2hex($encrypted); }
    }
    if($action == "decrypt")
    {
        $decrypted = openssl_decrypt(hex2bin($data), "AES-128-CBC", $ky, OPENSSL_RAW_DATA, $iv);
        if(!empty($decrypted)) { $output = $decrypted; }
    }
    return $output;
}

function response($status,  $msg, $data)
{
    header("Content-Type: application/json");
    header("Access-Control-Allow-Origin: *");
    $respo = array("status" => $status, "msg" => $msg, "data" => $data);
    exit(print(json_encode($respo)));
}

//===============================================================================================//

function fetch_cached_Streamlink($id)
{
    $output = "";
    global $FIRE_APP_CONFIGS;
    $plink_c_path  = $FIRE_APP_CONFIGS['APP_STORAGE_FOLDER']."/stream_".md5($id);
    if(file_exists($plink_c_path))
    {
        $stm_js_data = @json_decode(@file_get_contents($plink_c_path), true);
        if(isset($stm_js_data['link']) && isset($stm_js_data['time']))
        {
            if(time() < $stm_js_data['time'])
            {
                $output = $stm_js_data['link'];
            }
        }
    }
    if(empty($output)){ $output = fetch_live_Streamlink($id); }
    if(empty($output)){ $output = fetch_live_Streamlink($id); }
    return $output;
}

function fetch_live_Streamlink($id)
{
    $output = "";
    global $FIRE_APP_CONFIGS;
    $plink_c_path  = $FIRE_APP_CONFIGS['APP_STORAGE_FOLDER']."/stream_".md5($id);
    $plyrmdlink = fetch_cached_EmbedLink();
    $fire_heads = array("Referer: https://stream.crichd.vip/",
                        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36");
    if(!empty($plyrmdlink))
    {
        $embedrlink = $plyrmdlink."?player=desktop&live=".$id;
        $process = curl_init($embedrlink);
        curl_setopt($process, CURLOPT_HTTPHEADER, $fire_heads);
        curl_setopt($process, CURLOPT_HEADER, 0);
        curl_setopt($process, CURLOPT_TIMEOUT, 10);
        curl_setopt($process, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt($process, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($process, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($process, CURLOPT_SSL_VERIFYPEER, 0);
        $return = curl_exec($process);
        $effURL =  curl_getinfo($process, CURLINFO_EFFECTIVE_URL);
        $httpcode = curl_getinfo($process, CURLINFO_HTTP_CODE);
        curl_close($process);
        if(stripos($return, 'load({source: ') !== false)
        {
            $nxz = explode('load({source: ', $return);
            if(isset($nxz[1]))
            {
                $nxc = explode(',', $nxz[1]);
                if(isset($nxc[0])) {
                    $nxd = explode('function '.trim($nxc[0]), $return);
                    if(isset($nxd[1]))
                    {
                        $nan = explode('return([', $nxd[1]);
                        if(isset($nan[1]))
                        {
                            $non = explode('].join', $nan[1]);
                            if(isset($non[0]))
                            {
                                $urlaa = str_replace('"', '', $non[0]);
                                $urlbb = str_replace(",", "", $urlaa);
                                $urlcc = str_replace("\/", "/", $urlbb);
                                $urlcc = str_replace("////", "//", $urlcc);
                                if(filter_var($urlcc, FILTER_VALIDATE_URL)) 
                                {
                                    $output = $urlcc;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if(!empty($output))
    {
        $srjson = json_encode(array("time" => time() + 1800, "link" => $output));
        if(file_put_contents($plink_c_path, $srjson)){}
    }
    else
    {
        fetch_live_JsLink();
        fetch_live_EmbedLink();
    }
    return $output;
}

function fetch_cached_EmbedLink()
{
    $output = "";
    global $FIRE_APP_CONFIGS;
    $emd_path = $FIRE_APP_CONFIGS['APP_STORAGE_FOLDER']."/embedlink";
    if(file_exists($emd_path)) {
        $read_js_path = @file_get_contents($emd_path);
        if(filter_var($read_js_path, FILTER_VALIDATE_URL)) { $output = $read_js_path; }
    }
    if(empty($output)) { $output = fetch_live_EmbedLink(); }
    return $output;
}

function fetch_live_EmbedLink()
{
    $output = "";
    global $FIRE_APP_CONFIGS;
    $emd_path = $FIRE_APP_CONFIGS['APP_STORAGE_FOLDER']."/embedlink";
    $jscriptlink = fetch_cached_JsLink();
    $fire_heads = array("Referer: https://stream.crichd.vip/",
                        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36");
    if(!empty($jscriptlink))
    {
        $process = curl_init($jscriptlink);
        curl_setopt($process, CURLOPT_HTTPHEADER, $fire_heads);
        curl_setopt($process, CURLOPT_HEADER, 0);
        curl_setopt($process, CURLOPT_TIMEOUT, 10);
        curl_setopt($process, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt($process, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($process, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($process, CURLOPT_SSL_VERIFYPEER, 0);
        $return = curl_exec($process);
        $effURL =  curl_getinfo($process, CURLINFO_EFFECTIVE_URL);
        $httpcode = curl_getinfo($process, CURLINFO_HTTP_CODE);
        curl_close($process);
        if(stripos($return, 'ame src="') !== false)
        {
            $bnns = explode('ame src="', $return);
            if(isset($bnns[1]) && stripos($bnns[1], '?player=') !== false)
            {
                $bnnd = explode('?player=', $bnns[1]);
                if(isset($bnnd[0]))
                {
                    $rxlink = trim($bnnd[0]);
                    if($rxlink[0] == "/" && $rxlink[1] == "/") {
                        $output = "http:".$rxlink;
                    }
                    else {
                        $output = $rxlink;
                    } 
                }
            }
        }
    }
    if(!empty($output))
    {
        @file_put_contents($emd_path, $output);
    }
    else
    {
        fetch_live_JsLink();
    }
    return $output;
}

function fetch_cached_JsLink()
{
    $output = "";
    global $FIRE_APP_CONFIGS;
    $js_c_path = $FIRE_APP_CONFIGS['APP_STORAGE_FOLDER']."/jslink";
    if(file_exists($js_c_path)) {
        $read_js_path = @file_get_contents($js_c_path);
        if(filter_var($read_js_path, FILTER_VALIDATE_URL)) { $output = $read_js_path; }
    }
    if(empty($output)) { $output = fetch_live_JsLink(); }
    return $output;
}

function fetch_live_JsLink()
{
    $output = "";
    global $FIRE_APP_CONFIGS;
    $js_c_path = $FIRE_APP_CONFIGS['APP_STORAGE_FOLDER']."/jslink";
    if(isset($FIRE_APP_CONFIGS['JS_EMBED']) && filter_var($FIRE_APP_CONFIGS['JS_EMBED'], FILTER_VALIDATE_URL))
    {
        $fire_heads = array("Referer: https://m.crichd.vip/",
                            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36");
        $process = curl_init($FIRE_APP_CONFIGS['JS_EMBED']); 
        curl_setopt($process, CURLOPT_HTTPHEADER, $fire_heads); 
        curl_setopt($process, CURLOPT_HEADER, 0);
        curl_setopt($process, CURLOPT_ENCODING, '');
        curl_setopt($process, CURLOPT_TIMEOUT, 10); 
        curl_setopt($process, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt($process, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($process, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($process, CURLOPT_SSL_VERIFYPEER, 0);
        $return = curl_exec($process);
        $effURL =  curl_getinfo($process, CURLINFO_EFFECTIVE_URL);
        $httpcode = curl_getinfo($process, CURLINFO_HTTP_CODE);
        curl_close($process);
        $pattern = '/<script.*?src=["\'](.*?)["\'].*?>/';
        preg_match($pattern, $return, $matches);
        if(isset($matches[1]) && stripos($matches[1], ".js") !== false){
            $jslink = $matches[1];
            if($jslink[0] == "/" && $jslink[1] == "/") {
                $output = "http:".trim($jslink);
            }
            else {
                $output = trim($jslink);
            }
        }
        if(!empty($output)) { @file_put_contents($js_c_path, $output); }
    }
    return $output;
}


//=============================================================================================//

function tvcdata()
{
    $tv = '[{"id":"1ae062c88f455fc7cf6fec1039c2f785","title":"Star Sports 1 HD","logo":"https://i.postimg.cc/mD2B8h2h/Star-Sports-1-HD.png","cat":"Sports","lang":"English","link":"","sid":"star1in"},{"id":"9c2e1ca08269d0a2be2df321ca264f72","title":"Star Sports 2 HD","logo":"https://i.postimg.cc/8CzD4NzL/Star-Sports-HD-2.png","cat":"Sports","lang":"English","link":"","sid":"star2in"},{"id":"c4fc10f343784f045b9b40e8c342241d","title":"Star Sports 1 Hindi HD","logo":"https://i.postimg.cc/tg9j476D/Star-Sports-1-HD-Hindi.png","cat":"Sports","lang":"Hindi","link":"","sid":"starhindi"},{"id":"24cc4b6afd8568399b9bdf0df76c4bd8","title":"PTV Sports","logo":"https://i.postimg.cc/5NzQ2Qss/PTV-Sports.png","cat":"Sports","lang":"English","link":"","sid":"ptvpk"},{"id":"14b50855c25c4ab2114a4de00cebe760","title":"Willow HD","logo":"https://i.postimg.cc/XNCwDYR6/Willow.png","cat":"Sports","lang":"English","link":"","sid":"willowusa"},{"id":"4c881c8c762a15dab455eb8ff2420f5d","title":"Super Sport Cricket","logo":"https://i.postimg.cc/bwzkJHsq/Super-Cricket.png","cat":"Sports","lang":"English","link":"","sid":"supercricket"},{"id":"425059d92d1bdab653cba296a88fd0ff","title":"TEN Sports Pakistan","logo":"https://i.postimg.cc/cLbzBHqt/Ten-Sports.png","cat":"Sports","lang":"English","link":"","sid":"tenspk"},{"id":"7b32d768e7d08e0552c492131dba9796","title":"Willow Xtra","logo":"https://i.postimg.cc/KvQw4fJN/Willow-Xtra.png","cat":"Sports","lang":"English","link":"","sid":"willowextra"},{"id":"ca67f7766114b88216a9cedbf23d846e","title":"A Sports HD","logo":"https://i.postimg.cc/Dy7R2Hd0/A-Sports-HD.png","cat":"Sports","lang":"English","link":"","sid":"asportshd"},{"id":"d38683dbc4241a88b7ff41ea19d0c283","title":"Fox Cricket 501 HD","logo":"https://i.postimg.cc/Gp4ZWDPj/Fox-Cricket.png","cat":"Sports","lang":"English","link":"","sid":"fox501"},{"id":"117d59a8476870986d67988075584570","title":"Sky Sports Main Event","logo":"https://i.postimg.cc/nr32VRp9/Sky-Sports-Main-Event.png","cat":"Sports","lang":"English","link":"","sid":"skysme"},{"id":"054d71bb25ea273d317844be00dec11d","title":"Sky Sports Cricket","logo":"https://i.postimg.cc/x1J5Y37q/Sky-Sports-Cricket.png","cat":"Sports","lang":"English","link":"","sid":"skyscric"},{"id":"ea3ebdfdd1a0e5772aa4ba8106726611","title":"Sky Sports Action","logo":"https://i.postimg.cc/t70T6yXK/Sky-Sports-Action.png","cat":"Sports","lang":"English","link":"","sid":"skysact"},{"id":"1326d224acb492f08e9f2adb52930983","title":"Sky Sports Golf","logo":"https://i.postimg.cc/qB1x3FHz/Sky-Sports-Golf.png","cat":"Sports","lang":"English","link":"","sid":"skysgol"},{"id":"ad4cea504a00e532d8afe8fc08bdfab3","title":"Sky Sports Premier League","logo":"https://i.postimg.cc/85jMBpSc/Sky-Sports-Premiere-League.png","cat":"Sports","lang":"English","link":"","sid":"skysprem"},{"id":"d96555cfd390267e67d82ee1d33ef7a0","title":"Sky Sports Football","logo":"https://i.postimg.cc/7LPgh1tg/Sky-Sports-Football.png","cat":"Sports","lang":"English","link":"","sid":"skysfott"},{"id":"0996b06ce8928da5fd463e8692d846a0","title":"Sky Sports Arena","logo":"https://i.postimg.cc/PqG5FdYN/Sky-Sports-Arena.png","cat":"Sports","lang":"English","link":"","sid":"skysare"},{"id":"573edd07d0c66e24982f36d138b43814","title":"Sky Sports F1","logo":"https://i.postimg.cc/63t5tzHX/Sky-Sports-F1.png","cat":"Sports","lang":"English","link":"","sid":"skysfor1"},{"id":"a786d65d6b39193abc758dd0793de2a5","title":"Sky Sports Mix","logo":"https://i.postimg.cc/zDdXYCKs/Sky-Sports-Mix.png","cat":"Sports","lang":"English","link":"","sid":"skysmixx"},{"id":"6a1141594ee5ceab5e769f5995459a70","title":"Sky Sports News","logo":"https://i.postimg.cc/htmSmN6n/Sky-Sports-News.png","cat":"Sports","lang":"English","link":"","sid":"skyspnews"},{"id":"92fd996df8ee21050263d9791e184711","title":"BT Sport 1","logo":"https://i.postimg.cc/4d2Cq1qw/BT-Sports-1-HD.png","cat":"Sports","lang":"English","link":"","sid":"bbtsp1"},{"id":"2df691f07b22ba99778d1684eb860757","title":"BT Sport 2","logo":"https://i.postimg.cc/RZTvGwSp/BT-Sports-2-HD.png","cat":"Sports","lang":"English","link":"","sid":"bbtsp2"},{"id":"e74e2465d1c4cac2de7c3c49aaa9592f","title":"BT Sport 3","logo":"https://i.postimg.cc/Jh4MFttr/BT-Sports-3-HD.png","cat":"Sports","lang":"English","link":"","sid":"bbtsp3"},{"id":"2d10cd22aa2ab6d26408a0fe2cc788ce","title":"BT Sport 4","logo":"https://i.postimg.cc/K4SmpN3w/BT-Sport-4.png","cat":"Sports","lang":"English","link":"","sid":"bbtespn"},{"id":"dee40bb12a08e3db82456ebecd8d9d41","title":"LaLiga Tv","logo":"https://i.postimg.cc/mkMPrhYx/La-Liga-TV.png","cat":"Sports","lang":"English","link":"","sid":"laligauk"},{"id":"13d3d6d0c5ac1f2b02e279109eaaaba3","title":"EuroSport 1","logo":"https://i.postimg.cc/K8s3JXvH/Eurosport-1.png","cat":"Sports","lang":"English","link":"","sid":"eurosp1"},{"id":"0c10f093e0030d039681aca4388c59e4","title":"EuroSport 2","logo":"https://i.postimg.cc/Px1LXPbg/Eurosport-2.png","cat":"Sports","lang":"English","link":"","sid":"eurosp2"},{"id":"ae270065146b68f8225bb571ce29b1d4","title":"Fox Sports 502 HD","logo":"https://i.postimg.cc/0Nwjnb4z/Fox-Sports.png","cat":"Sports","lang":"English","link":"","sid":"fox5022"},{"id":"0017f5eeb72c1ae4bcaeea23463aa1c4","title":"Fox Sports 503 HD","logo":"https://i.postimg.cc/0Nwjnb4z/Fox-Sports.png","cat":"Sports","lang":"English","link":"","sid":"fox503"},{"id":"99704f044d7d2e6be8b5ac9ae3718466","title":"Fox Sports 504 HD","logo":"https://i.postimg.cc/0Nwjnb4z/Fox-Sports.png","cat":"Sports","lang":"English","link":"","sid":"fox504"},{"id":"a3d53d2255f4888be091e2d3662479c7","title":"Fox Sports 505 HD","logo":"https://i.postimg.cc/0Nwjnb4z/Fox-Sports.png","cat":"Sports","lang":"English","link":"","sid":"fox505"},{"id":"215a391ef40587eb68dbf1196d34d650","title":"Fox Sports 506 HD","logo":"https://i.postimg.cc/0Nwjnb4z/Fox-Sports.png","cat":"Sports","lang":"English","link":"","sid":"fox506"},{"id":"381efb65ff186b34e5d98d4750346959","title":"WWE Network","logo":"https://i.postimg.cc/SRNmBsg7/WWE.png","cat":"Sports","lang":"English","link":"","sid":"wwe"},{"id":"c3b852d0f1ee7d392d645026c363bd92","title":"Geo Super","logo":"https://i.postimg.cc/HnGhMPyJ/Geo-Super.png","cat":"Sports","lang":"Urdu","link":"","sid":"geosp"},{"id":"595f13e713ade9afc850f28c3f3673a7","title":"Bein Sports 1 English","logo":"https://i.postimg.cc/GpCtMcnz/Bein-Sports-HD-1.png","cat":"Sports","lang":"English","link":"","sid":"bein1en"},{"id":"aba40e195b69ee5ca7ecbe08368d2737","title":"Bein Sports 2 English","logo":"https://i.postimg.cc/ZKNJX1cQ/Bein-Sports-HD2.png","cat":"Sports","lang":"English","link":"","sid":"bein2en"},{"id":"52b49f8a8cee2a3ac25bf4be0ade294b","title":"Bein Sports 3 English","logo":"https://i.postimg.cc/Z5k6Szhv/Bein-Sports-HD-3.png","cat":"Sports","lang":"English","link":"","sid":"bein3en"},{"id":"921d9777020d8c2dfdb851e2d9e0bad1","title":"Bein Sports 1 Premium","logo":"https://i.postimg.cc/6QtbL1zg/Bein-Sports-Premium-1.png","cat":"Sports","lang":"English","link":"","sid":"bein1prem"},{"id":"547e29a31374bb712487e05dbed835dc","title":"Bein Sports 2 Premium","logo":"https://i.postimg.cc/6q2Mps52/Bein-Sports-Premium-2.png","cat":"Sports","lang":"English","link":"","sid":"bein2prem"},{"id":"6c8125aa2e597b9c4f99a196fa9c8705","title":"Bein Sports 3 Premium","logo":"https://i.postimg.cc/k5jrVm9f/Bein-Sports-Premium-3.png","cat":"Sports","lang":"English","link":"","sid":"bein3prem"},{"id":"0aa00dadf82f57e48ec094d235c637cc","title":"SuperSport Football","logo":"https://i.postimg.cc/8zgdQf8V/Super-Sport-Football.png","cat":"Sports","lang":"English","link":"","sid":"superfotball"},{"id":"b3943d0e57072defe4279fb1f04b5c86","title":"SuperSport Premier","logo":"https://i.postimg.cc/nzrBYvmq/Super-Sport-Premiere-League.png","cat":"Sports","lang":"English","link":"","sid":"superpremier"},{"id":"7f1e38f599f7964363f48aab8aee2511","title":"SuperSport Laliga","logo":"https://i.postimg.cc/FR6cP7b8/Super-Sport-La-Liga.png","cat":"Sports","lang":"English","link":"","sid":"superlaliga"},{"id":"4e4aa5dcfbc9f8b61d779fd68cd05c07","title":"SuperSport Rugby","logo":"https://i.postimg.cc/sgznPNgS/Super-Sport-Rugby.png","cat":"Sports","lang":"English","link":"","sid":"supersrugby"},{"id":"6ff312fd796008ff2af73bbffe5a8f82","title":"SuperSport Grandstand","logo":"https://i.postimg.cc/0QzZ2gVg/Super-Sport-Grandstand.png","cat":"Sports","lang":"English","link":"","sid":"supergrandstand"},{"id":"90783bd0b0627cebbda63c7effa0abce","title":"SuperSport Tennis","logo":"https://i.postimg.cc/7YFDnDF6/Super-Sport-Tennis.png","cat":"Sports","lang":"English","link":"","sid":"supertennis"},{"id":"a9c20abb043c41bab9ec8201e0733783","title":"SuperSport Action","logo":"https://i.postimg.cc/9Mhr8ZsD/Super-Sport-Action.png","cat":"Sports","lang":"English","link":"","sid":"superactions"},{"id":"3e7b358bd303aa4ca346774500731553","title":"SuperSport Golf","logo":"https://i.postimg.cc/ncgVSqDn/Super-Sport-Golf.png","cat":"Sports","lang":"English","link":"","sid":"supergolf"},{"id":"77df99fe3ce533583d4d07b519430e71","title":"SuperSport Maximo","logo":"https://i.postimg.cc/4xw164Mk/Super-Sport-Maximo.png","cat":"Sports","lang":"English","link":"","sid":"supermeximo"},{"id":"0c5f421a4ac54f0b30ef3f3e310eba70","title":"Bein Sports 1 AR","logo":"https://i.postimg.cc/BbMvhyG6/Bein-Sports.png","cat":"Sports","lang":"Arabic","link":"","sid":"bein1arab"},{"id":"axc46641d8421cab67ab2d76210fc795","title":"Bein Sports 2 AR","logo":"https://i.postimg.cc/BbMvhyG6/Bein-Sports.png","cat":"Sports","lang":"Arabic","link":"","sid":"bein2arab"},{"id":"62208b295e3dd1efdf2269ddeebf7cd5","title":"Bein Sports 3 AR","logo":"https://i.postimg.cc/BbMvhyG6/Bein-Sports.png","cat":"Sports","lang":"Arabic","link":"","sid":"bein3arab"},{"id":"hb381e2bfc17989333a3e30df2ccce61","title":"Bein Sports 4 AR","logo":"https://i.postimg.cc/BbMvhyG6/Bein-Sports.png","cat":"Sports","lang":"Arabic","link":"","sid":"bein4arab"},{"id":"23413405e52af946372ffc9fd8488f1c","title":"Bein Sports 5 AR","logo":"https://i.postimg.cc/BbMvhyG6/Bein-Sports.png","cat":"Sports","lang":"Arabic","link":"","sid":"bein5arab"},{"id":"209726c2c7485c3963d4edc3e7937c0b","title":"Bein Sports 6 AR","logo":"https://i.postimg.cc/BbMvhyG6/Bein-Sports.png","cat":"Sports","lang":"Arabic","link":"","sid":"bein6arab"},{"id":"6393161d6ffbb4739DDD3dee1b3204d2","title":"Bein Sports 7 AR","logo":"https://i.postimg.cc/BbMvhyG6/Bein-Sports.png","cat":"Sports","lang":"Arabic","link":"","sid":"bein7arab"},{"id":"cc387e24b33b57f38b405e47d22df149","title":"Bein Sports 1 FR","logo":"https://i.postimg.cc/cJPp7cgn/Bein-Sports-1-FR.png","cat":"Sports","lang":"French","link":"","sid":"bein1fr"},{"id":"b56287756907ced5f557c002405f6575","title":"Bein Sports 2 FR","logo":"https://i.postimg.cc/mZYvMCbP/Bein-Sports-2-FR.png","cat":"Sports","lang":"French","link":"","sid":"bein2fr"},{"id":"180d35164499a00805e017354d00d5de","title":"Bein Sports 3 FR","logo":"https://i.postimg.cc/m2VKp41R/Bein-Sports-3-FR.png","cat":"Sports","lang":"French","link":"","sid":"bein3fr"},{"id":"831afdd8f6449bed53df4448e7b02f61","title":"SuperSport Variety 1","logo":"https://i.postimg.cc/Gmhq4s2n/Super-Sport-Variety-1.png","cat":"Sports","lang":"English","link":"","sid":"hdchnl6"},{"id":"d93c1141b93cedf3a3d83dd6776081c1","title":"SuperSport Variety 2","logo":"https://i.postimg.cc/nrJ1pX55/Super-Sport-Variety-2.png","cat":"Sports","lang":"English","link":"","sid":"hdchnl7"},{"id":"07ecfef5e99674d167af5030ccf28854","title":"SuperSport Variety 3","logo":"https://i.postimg.cc/QdtJ8G4X/Super-Sport-Variety-3.png","cat":"Sports","lang":"English","link":"","sid":"hdchnl8"},{"id":"957cWb1db00b19387aeb318296adab1d","title":"SuperSport Variety 4","logo":"https://i.postimg.cc/28HnX9zg/Super-Sport-Variety-4.png","cat":"Sports","lang":"English","link":"","sid":"hdchnl9"},{"id":"39a6828ed06f7e9e859f03eca83fbba8","title":"Via Play Sports 1","logo":"https://i.postimg.cc/SKGnjz66/Via-Play-Sports1.png","cat":"Sports","lang":"English","link":"","sid":"premieruk"},{"id":"007d11094810797b78def0b6307c6af2","title":"Via Play Sports 2","logo":"https://i.postimg.cc/13hXHKM0/Via-Play-Sports2.png","cat":"Sports","lang":"English","link":"","sid":"hdchnl2"},{"id":"ee01467dde677f52730c692dd37cc514","title":"Via Play Xtra","logo":"https://i.postimg.cc/W49JXkd2/Via-Play-Xtra.png","cat":"Sports","lang":"English","link":"","sid":"hdchnl3"},{"id":"ac39ba84953e6bcd9c0f8e2e0727af7b","title":"Super Sports PSL","logo":"https://i.postimg.cc/QN7HWPJN/Super-Sports-PSL.png","cat":"Sports","lang":"English","link":"","sid":"superpsl"}]';
    return json_decode($tv, true);
}

?>